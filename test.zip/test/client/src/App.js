import './App.css';
import ParentContainer from './components/ParentContainer';

function App() {
 
  return (
    <div className="App">
     <ParentContainer />
    </div>

    
  );
}

export default App;

