import React from 'react';
import {Link, navigate} from '@reach/router';
import axios from 'axios';

const DisplayAuthors = ({authors, setPing}) =>{

    const deleteHandler =(id) =>{
        axios.delete("http://localhost:8000/api/authors/" + id)
        .then(res => setPing(true))
        .catch(err => console.log(err))
    }

    return(
        <div>
            <Link to={"/new"}>add a pet to the ahelter </Link>
            <p>These pets are looking for a good home :</p>
            <table >
                
                <thead>
                    <tr>
                        <th >Name</th>
                        <th > Type</th>
                        <th > Actions</th>
                    </tr>
                </thead>
                <tbody>
                {
                        authors.map((author, idx)=>{
                            return(
                                <tr key={idx}>
                                    <td>{author.name}</td>
                                    <td>{author.Type}</td>
                                    <td>
                                        <button onClick={()=>{navigate(`/edit/${author._id}`)}} >Edit</button>
                                        <button onClick={() => deleteHandler(author._id)} >Delete</button>
                                    </td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>

        </div>
    )
}

export default DisplayAuthors;