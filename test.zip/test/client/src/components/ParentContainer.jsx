import React ,{useState,useEffect} from'react';
import axios from 'axios';
import { Router } from "@reach/router";
import DisplayAuthors from './DisplayAuthors';
import AddAuthor from './AddAuthor';
import EditAuthor from './EditAuthor';


const ParentContainer = () => {
    const [authors, setAuthors] = useState([]);
    const [ping, setPing] = useState(false);


    useEffect(() => {
        axios.get("http://localhost:8000/api/authors")
            .then(res => {
                setAuthors(                                     
                    res.data.sort(function(a, b) {             
                        return a.name.localeCompare(b.name);    
                    })                                          
                );

                setPing(false);
            })
            .catch(err=>console.log(err));
    }, [ping]);

return (
    <div>
        
        <Router>
            <AddAuthor path="/new" setPing={setPing}  />
            <DisplayAuthors path={"/"} authsetPing={setPing} authors={authors} setPing={setPing}/>
            <EditAuthor path= "/edit/:id"  setPing={setPing} />
        </Router>
        
    </div>
)}

export default ParentContainer;
