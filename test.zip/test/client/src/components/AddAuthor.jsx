import React, { useState } from 'react';
import {Link,navigate} from '@reach/router';
import axios from 'axios';

const AddAuthor = ({setPing}) => {
    const [name,setName] = useState("");
    const [errors, setErrors] = useState([]);



    const formHandler= e=> {
        e.preventDefault();
        axios.post("http://localhost:8000/api/authors", {name})
             .then(res =>{
                navigate("/");
                setPing(true);
             })
             .catch(errors=>{ console.log(errors)
             })
    }



    return(
        <div>
            <h3>Pet Shelter</h3>
            <Link to = '/'>back to home</Link>
            <p>Know a pet needing a home?</p>
            <form onSubmit={formHandler}>
            <label > pet Name:</label>
            <input type="text" onChange={(e)=>setName(e.target.value)} />
            <label > pet Type:</label>
            <input type="text" onChange={(e)=>setName(e.target.value)} />
            <label > pet Description:</label>
            <input type="text" onChange={(e)=>setName(e.target.value)} />

            <p>pet skills (optional):</p>
            <label >skill 1 </label>
            <input type="text" onChange={(e)=>setName(e.target.value)} />
            <label >skill 2 </label>
            <input type="text" onChange={(e)=>setName(e.target.value)} />
            <label >skill 3 </label>
            <input type="text" onChange={(e)=>setName(e.target.value)} />


            <button color='blue' onClick={()=>{navigate("/")}}>Cancel</button>
            <button color='blue' type='submit'>Submit</button>
            </form>

        </div>
    )
}

export default AddAuthor;
