import React, { useEffect, useState } from 'react';
import { Link, navigate } from "@reach/router";
import axios from 'axios';


const EditAuthor = ({id, setPing}) =>{

    const [name, setName] = useState(" ");
    const [errors, setErrors] = useState([]);

    useEffect(()=>{
        axios.get("http://localhost:8000/api/authors/" + id)
            .then(res => {
                setName(res.data.name);
            })
            .catch(err => console.log(err))

    },[id])

    const formHandler = (e) =>{
        e.preventDefault();
        axios.put("http://localhost:8000/api/authors/" + id, {name})
            .then(res => {
                navigate("/");
                setPing(true);
            })
            .catch(err => {
                console.log(err);
            })
    }


    return(
        
        name !== "" ?
            <div>
           
            <Link to = '/'>Home</Link>
            <p>Edit Garfield</p>

            <form onSubmit={formHandler}>
            <label > pet Name:</label>
            <input type="text" onChange={(e)=>setName(e.target.value)} />
            <label > pet Type:</label>
            <input type="text" onChange={(e)=>setName(e.target.value)} />
            <label > pet Description:</label>
            <input type="text" onChange={(e)=>setName(e.target.value)} />

            <p>pet skills (optional):</p>
            <label >skill 1 </label>
            <input type="text" onChange={(e)=>setName(e.target.value)} />
            <label >skill 2 </label>
            <input type="text" onChange={(e)=>setName(e.target.value)} />
            <label >skill 3 </label>
            <input type="text" onChange={(e)=>setName(e.target.value)} />


            <button color='blue' onClick={()=>{navigate("/")}}>Cancel</button>
            <button color='blue' type='submit'>Edit Pet </button>
            </form>

        </div>

    :
    <div>
        <h4>We're sorry, but we could not find the author you are looking for. <br />
        Would you like to add this author to our database?</h4>
        <button onClick={() => navigate("/new")} >Yes</button>
    </div>
    )
}
export default EditAuthor;