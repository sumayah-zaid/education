const { Author } = require('../models/Author');


module.exports.createAuthor = (req, res) => {
    const { name} = req.body;
        Author.create({
        name
    })
        .then(Author => res.json(Author))
        .catch( err => res.status(400).json(err))
}


module.exports.getAllAuthor = (req, res) => {
    Author.find({})
        .then(Author => res.json(Author))
        .catch( err => res.status(400).json(err))
}


module.exports.getOneAuthor = (req, res) => {
    Author.findOne({_id: req.params.id})
        .then(Author => res.json(Author))
        .catch( err => res.status(400).json(err))
}

module.exports.deleteAuthor = (req, res) => {
    Author.deleteOne({ _id: req.params.id })
        .then(deleteConfirmation  => res.json(deleteConfirmation ))
        .catch( err => res.status(400).json(err))
}

module.exports.updateAuthor = (req, res) => {
    Author.findByIdAndUpdate({_id: req.params.id}, req.body, {new:true, runValidators: true})
        .then(Author => res.json(Author))
        .catch( err => res.status(400).json(err))
    }

