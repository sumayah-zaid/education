using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using viewModelFun.Models;

namespace viewModelFun.Controllers
{
    public class HomeController : Controller
    {
        public List<User> CreateUsers()
        {
            return new List<User>
            {
                new User(){FirstName="Layla", LastName="Al-Asker"},
                new User(){FirstName="Saja", LastName="Alhummery"},
                new User(){FirstName="Hala", LastName="Al-Mulhem"},
                new User(){FirstName="Somayiah", LastName="Al-Sheref"},
                new User(){FirstName="Zaid", LastName="Al-Shemmery"},
                new User(){FirstName="Samar", LastName="Al-Joody"}
            };
        }

        [HttpGet]    
        [Route("")] 
        public ViewResult Index()
        {
            string msg = "Welcome to the Assigmentz View Model Fun!";
            return View("Index", msg);
        }

        [HttpGet("numbers")] 
        public ViewResult Numbers()
        {
            int[] num = {1,2,3,4,5,6};
            return View(num);
        }

        [HttpGet("users")] 
        public ViewResult Users()
        {
            var users = CreateUsers();
            return View(users);
        }

        [HttpGet("user")] 
        public ViewResult User()
        {
            var rand = new Random();
            var users = CreateUsers();
            var user = users[rand.Next(users.Count)];
            return View(user);
        }
    }
        
    
}