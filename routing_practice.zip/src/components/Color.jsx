import React from 'react';

const Color = props => {
    return (
        <div style={{ backgroundColor: props.bgColor, color: props.color, height: "100px"}}>
            {
                isNaN(props.numberWord) ? <h1 style={{ paddingTop: "30px"}} >The word is: {props.numberWord}</h1> : <h1 style={{ paddingTop: "30px"}}>The number is: {props.numberWord}</h1>
            }
        </div>
    );
};

export default Color;