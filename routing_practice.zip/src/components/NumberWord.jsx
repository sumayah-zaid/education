import React from 'react';

const NumberWord = props => {
    return (
        <div>
            {
                isNaN(props.numberWord) ? <h1>The word is: {props.numberWord}</h1> : <h1>The number is: {props.numberWord}</h1>
            }
        </div>
    );
};

export default NumberWord;