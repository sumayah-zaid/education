import React, { useState } from 'react';
import {Link,navigate} from '@reach/router';
import { Button } from '@material-ui/core';
import axios from 'axios';

const AddAuthor = ({setPing}) => {
    const [name,setName] = useState("");
    const [errors, setErrors] = useState([]);



    const formHandler= e=> {
        e.preventDefault();
        axios.post("http://localhost:8000/api/authors", {name})
             .then(res =>{
                navigate("/");
                setPing(true);
             })
             .catch(err=>{
                const errRes = err.response.data.errors;
                const errArr = [];
                for (const key of Object.keys(errRes)){
                    errArr.push(errRes[key].message);
                }
                setErrors(errArr);
             })
    }



    return(
        <div>
            <h3>Favorite authors</h3>
            <Link to = '/'>Home</Link>
            <p>Add a new author:</p>


            <form onSubmit={formHandler}>

                {errors.map((err, idx) => {
                    return(
                        <p key={idx} style={{color:"red"}} >{err}</p>
                    )
                })}


                <label > Name:</label>
                <input type="text" onChange={(e)=>setName(e.target.value)} />

                <Button color='blue' onClick={()=>{navigate("/")}}>Cancel</Button>
                <Button color='blue' type='submit'>Submit</Button>
            </form>
           

            

            

        </div>
    )
}

export default AddAuthor;
