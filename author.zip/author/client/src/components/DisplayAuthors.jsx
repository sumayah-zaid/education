import React from 'react';
import {Link, navigate} from '@reach/router';
import axios from 'axios';

const DisplayAuthors = ({authors, setPing}) =>{


    const deleteHandler =(id) =>{
        axios.delete("http://localhost:8000/api/authors/" + id)
        .then(res => setPing(true))
        .catch(err => console.log(err))
    }

    return(
        <div>
            <Link to={"/new"}>add an author </Link>


            <p>We have quites by:</p>

           
            <table >
                
                <thead >
                    <tr>
                        <th scope="col">Author</th>
                        <th scope="col"> Action avallabel</th>
                    </tr>
                </thead>
                <tbody>
                {
                        authors.map((author, idx)=>{

                            return(
                                <tr key={idx}>
                                    <td>{author.name}</td>
                        
                                    <td>
                                    <button onClick={()=>{navigate(`/edit/${author._id}`)}} >Edit</button>
                                        <button onClick={()=>{navigate(`/details/${author._id}`)}} >Details </button>
                                        <button onClick={() => deleteHandler(author._id)} >Delete</button>
                                    </td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
            
        

        </div>
    )
}

export default DisplayAuthors;