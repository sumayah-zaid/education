import React,{useState,useEffect}from 'react';
import { Link, navigate } from "@reach/router";
import axios from 'axios';


const Details = ({id,setPing})=>{
    const [authors, setAuthors] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:8000/api/authors/'+ id )
            .then(res => setAuthors(res.data))
            .catch(err=>console.log(err));        
    }, [id]);

  

     const deleteHandler =(id) =>{
        axios.delete("http://localhost:8000/api/authors/" + id)
        .then(res =>{
            navigate("/");
            setPing(true);
         })
        .catch(err => console.log(err))
    }

return(
    <div>
    
        <button className="button" onClick={() => deleteHandler(authors._id)} >Delete</button>


        <div className="card">
           
        
        <h1>Details about : {authors.name}</h1>
                
        
        
        </div>
       
       

    </div>
)
}

export default Details;