import React, { useEffect, useState } from 'react';
import { Link, navigate } from "@reach/router";
import axios from 'axios';


const EditAuthor = ({id, setPing}) =>{

    const [name, setName] = useState(" ");
    const [errors, setErrors] = useState([]);

    useEffect(()=>{
        axios.get("http://localhost:8000/api/authors/" + id)
            .then(res => {
                setName(res.data.name);
            })
            .catch(err => console.log(err))

    },[id])


    const formHandler = (e) =>{
        e.preventDefault();
        axios.put("http://localhost:8000/api/authors/" + id, {name})
            .then(res => {
                navigate("/");
                setPing(true);
            })
            .catch(err => {
                console.log(err);
                const errRes = err.response.data.errors;
                const errArr = [];
                for (const key of Object.keys(errRes)){
                    errArr.push(errRes[key].message);
                }
                setErrors(errArr);
            })
    }


    return(
        
        name !== "" ?   
        
            <div>
            
                    <h3>Favorite authors</h3>

                
            
            <Link to = '/'>Home</Link>
            <p>Edit this author</p>

       
                <form  className="divForm" onSubmit={formHandler}>

                {errors.map((err, idx) => {
                    return(
                        <p key={idx} style={{color:"red"}} >{err}</p>
                    )
                })}


                <label > Name:</label>
                <input type="text" onChange={(e)=>setName(e.target.value)} />
                <button color='blue' onClick={()=>{navigate("/")}}>Cancel</button>
                <button color='blue' type='submit'>Submit</button>
            </form>

            
            

        </div>

    :
    <div>
        <h4>We're sorry, but we could not find the author you are looking for. <br />
        Would you like to add this author to our database?</h4>
        <button onClick={() => navigate("/new")} >Yes</button>
    </div>
    )
}
export default EditAuthor;