const AuthorController = require('../controllers/authors');


module.exports = app=>{
    app.post('/api/authors', AuthorController.createAuthor);
    app.get('/api/authors',AuthorController.getAllAuthor);
    app.get('/api/authors/:id', AuthorController.getOneAuthor);
    app.delete('/api/authors/:id', AuthorController.deleteAuthor);
    app.put("/api/authors/:id", AuthorController.updateAuthor);

}