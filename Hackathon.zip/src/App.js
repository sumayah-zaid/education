
import Questions from './components/Questions';

function App() {
  return (
    <div className="container">
      <Questions />
    </div>
  );
}

export default App;
