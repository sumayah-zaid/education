using Microsoft.AspNetCore.Mvc;
namespace dojoSurvey.Controllers
{
    public class FormController : Controller
    {
        [HttpGet ("")]
        public ViewResult Index()
        {
            return View();
        }

        [HttpPost("submit")]
        public RedirectToActionResult FormHandler(string name, string location, string lang, string comment)
        {
            return RedirectToAction("FormResult", new{name=name, location=location, lang=lang, comment=comment});
        }

        [HttpGet ("result")]
        public ViewResult FormResult (string name, string location, string lang, string comment)
        {
            ViewBag.name = name;
            ViewBag.location = location;
            ViewBag.lang = lang;
            ViewBag.comment = comment;
            return View();
        }
        
    }
}