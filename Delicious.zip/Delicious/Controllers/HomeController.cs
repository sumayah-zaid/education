﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Delicious.Models;

namespace Delicious.Controllers
{
    public class HomeController : Controller
    {
       private MyContext _context;
       public HomeController(MyContext context)
       {
           _context = context;
       }

         [HttpGet("")]
      public IActionResult Index()
        {
            return View(_context.Disheses.OrderByDescending(d => d.createdAt));
        }


         [HttpPost("AddDish")]
       public IActionResult AddDish() => View();

        [HttpPost("create")]
        public IActionResult Create(Dishes newDish)
       {
           if(ModelState.IsValid)
           {
            _context.Add(newDish);
            _context.SaveChanges();
            return RedirectToAction("Index"); 
           }
           else
           {
               return View("AddDish");
           }
        }
    }
  }
