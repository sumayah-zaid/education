from django.shortcuts import render, redirect
from django.contrib import messages
from main.models import *
import bcrypt

# Create your views here.


def root(request):
    return render(request, "index.html")


def register(request):
    request.session['action'] = "reg"

    errors = Users.objects.register_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/")
    else:

        first_name = request.POST['fname']
        last_name = request.POST['lname']
        email = request.POST['email']
        password = request.POST['password']
        birthday = request.POST['date']

        pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

        user = Users.objects.create(
            first_name=first_name, last_name=last_name, email=email, password=pw_hash, birthday=birthday)

        request.session['id'] = user.id
        request.session['username'] = first_name
        return redirect("/books")


def login(request):
    request.session['action'] = "login"
    errors = Users.objects.login_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/")
    else:
        user = Users.objects.get(email=request.POST['email'])
        first_name = user.first_name
        request.session['id'] = user.id
        request.session['username'] = first_name
        return redirect("/books")


def books(request):
    if request.session is None:
        return redirect("/")
    else:
        context = {
            "user" : Users.objects.get(id=request.session['id']),
            "all_books": Books.objects.all(),
        }
        return render(request, "books.html", context)

def add_favorite(request, id):
    user = Users.objects.get(id=request.session['id'])
    user.liked_books.add(Books.objects.get(id=id))
    return redirect("/books")

def remove_favorite(request, id):
    user = Users.objects.get(id=request.session['id'])
    user.liked_books.remove(Books.objects.get(id=id))
    return redirect("/books")

def new_book(request):
    book_title = request.POST['title']
    book_desc = request.POST['desc']
    uploader_id = request.session['id']
    uploader = Users.objects.get(id=uploader_id)

    book = Books.objects.create(
        title=book_title, desc=book_desc, uploaded_by=uploader)
    book.favorite.add(uploader)
    return redirect("/books")


def book_info(request, id):
    context = {
        "book_info": Books.objects.get(id=id),
        "fave_books": Users.objects.get(id=request.session['id']).liked_books.all(),
    }
    if request.session['id'] != Books.objects.get(id=id).uploaded_by.id:
        return render(request, "book_info.html", context)
    else:
        
        return render(request, "editable_book_info.html", context)


def update_book(request, id):
    new_title = request.POST['title']
    new_desc = request.POST['desc']
    btn = request.POST['book_action']
    book = Books.objects.get(id=id)
    if btn == "delete":
        book.delete()
        return redirect("/books")
    else:
        book.title = new_title
        book.desc = new_desc
        book.save()

        if request.session['id'] != Books.objects.get(id=id).uploaded_by.id:
            return render(request, "book_info.html", context)
        else:
            context = {
                "book_info": Books.objects.get(id=id),
            }
            return render(request, "editable_book_info.html", context)


def logout(request):
    request.session.flush()
    return redirect("/")
