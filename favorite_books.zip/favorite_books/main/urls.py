from django.urls import path
from . import views

urlpatterns = [
    path("", views.root),
    path("register", views.register),
    path("login", views.login),
    path("books", views.books),
    path("logout", views.logout),
    path("new_book", views.new_book),
    path("books/<int:id>", views.book_info),
    path("update/<int:id>", views.update_book),
    path("add_favorite/<int:id>", views.add_favorite),
    path("remove_favorite/<int:id>", views.remove_favorite),
]