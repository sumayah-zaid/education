import './App.css';
import HomePage from './components/HomePage';
import {Router} from '@reach/router';
import People from './components/People';
import Planets from './components/Planets';
import Species from './components/Species';
import Films from './components/Films';
import StarShips from './components/StarShips';



function App() {
  return (
    <div className="App">
      <HomePage />
      <Router>
        <People path="/people/:idx" />
        <Planets path="/planets/:idx" />
        <Species path="/species/:idx" />
        <Films path="/films/:idx" />
        <StarShips path="/starship/:idx" />
      </Router>
    </div>
  );
}

export default App;
