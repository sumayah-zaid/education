import React, { useState } from 'react';
import {navigate} from '@reach/router';

const HomePage = props => {
    // const [list, setList] = useState(['people', 'planets', 'species', 'films', 'starship']); we can do that
    const list = ['Select an item', 'people', 'planets', 'species', 'films', 'starship'] // also by this way
    const [takeInfo, setTakeInfo] = useState("");
    const [idx, setIdx] = useState(1);

    const formHandler = e => {
        e.preventDefault();
        navigate(`/${takeInfo}/${idx}`) // we can do that 
        // navigate("/" + takeInfo + "/" + id) // or this way
        console.log(takeInfo);
        setIdx("");
    }

    return(
        <form onSubmit={formHandler} className="container w-80 mt-3 mb-5">
            <label className="d-inline m-2">Search For :</label>
            <select className="input-group-text d-inline m-2 select" onChange={e => setTakeInfo(e.target.value)}>
                { list.map((item, id) => (
                    <option value={item} key={id}>{item}</option>
                ))}
            </select>
            <label>ID :</label>
            <input type="number" className="input-group-text d-inline m-2 number" value={idx} onChange={e => setIdx(e.target.value)} />
            <button className="btn btn-primary btn-inline m-2 input">Search</button>
        </form>
    )
}

export default HomePage;