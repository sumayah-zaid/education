import axios from 'axios';
import React, { useEffect, useState } from 'react';

const Planets = props => {
    const [planets, setPlanets] = useState({
        name : "",
        climate : "",
        terrain : "",
        surface_water : "",
        population : ""
    })
    

    useEffect(() => {
        axios.get(`https://swapi.dev/api/planets/${props.idx}/`)
        .then(res => setPlanets(res.data))
        .catch(err => console.log(err))
    },[])

    return(
        <div>
            <h1>{planets.name}</h1>
            <h3>Climate: {planets.climate}</h3>
            <h3>Terrain: {planets.terrain}</h3>
            <h3>Surface Water: {planets.surface_water}</h3>
            <h3>Population: {planets.population}</h3>
        </div>
    )
}
export default Planets;