import axios from 'axios';
import React, { useEffect, useState } from 'react';

const Films = props => {
    const [films, setFilms] = useState({
        title : "",
        director : "",
        producer : "",
        release_date : "",
    })
    

    useEffect(() => {
        axios.get(`https://swapi.dev/api/films/${props.idx}/`)
        .then(res => setFilms(res.data))
        .catch(err => console.log(err))
    },[])

    return(
        <div>
            <h1>Title: {films.title}</h1>
            <h3>Director: {films.director}</h3>
            <h3>Producer: {films.producer}</h3>
            <h3>Release Date: {films.release_date}</h3>
        </div>
    )
}
export default Films;