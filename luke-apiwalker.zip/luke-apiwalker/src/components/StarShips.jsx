import axios from 'axios';
import React, { useEffect, useState } from 'react';

const StarShips = props => {
    const [starships, setStarShips] = useState({
        name : "",
        model : "",
        manufacturer : "",
        length : "",
        passengers : "",
        consumables : ""
    })
    

    useEffect(() => {
        axios.get(`https://swapi.dev/api/starships/${props.idx}/`)
        .then(res => setStarShips(res.data))
        .catch(err => console.log(err))
    },[])

    return(
        <div>
            <h1>Name: {starships.name}</h1>
            <h3>Model: {starships.model}</h3>
            <h3>Manufacturer: {starships.manufacturers}</h3>
            <h3>Length: {starships.length}</h3>
            <h3>Passengers: {starships.passengers}</h3>
            <h3>Consumables: {starships.consumables}</h3>
        </div>
    )
}
export default StarShips;