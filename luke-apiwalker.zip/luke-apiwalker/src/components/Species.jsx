import axios from 'axios';
import React, { useEffect, useState } from 'react';

const Species = props => {
    const [species, setSpecies] = useState({
        name : "",
        average_height : "",
        skin_colors : "",
        hair_colors : "",
        eye_colors : "",
        language : ""
    })
    

    useEffect(() => {
        axios.get(`https://swapi.dev/api/species/${props.idx}/`)
        .then(res => setSpecies(res.data))
        .catch(err => console.log(err))
    },[props.idx])

    return(
        <div>
            <h1>Name: {species.name}</h1>
            <h3>Average Height: {species.average_height}</h3>
            <h3>Skin Colors: {species.skin_colors}</h3>
            <h3>Hair Colors: {species.hair_colors}</h3>
            <h3>Eye Colors: {species.eye_colors}</h3>
            <h3>Language: {species.language}</h3>
        </div>
    )
}
export default Species;