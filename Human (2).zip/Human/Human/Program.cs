﻿using System;

namespace Human
{
    class Program
    {
        static void Main(string[] args)
        {
          Human hum = new Human("soma");
          

          Console.WriteLine(hum.Name);
        }
    }
}
