﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Demo.Models;

namespace Demo.Controllers
{
    public class HomeController : Controller
    {

        [HttpGet("")]
        public ViewResult Index()
        { 
            Product[] myProducts = new Product[]
                {
                    new Product { Name = "Jeans", Category = "Clothing", Price = 24.7 },
                    new Product { Name = "Socks", Category = "Clothing", Price = 8.12 },
                    new Product { Name = "Scooter", Category = "Vehicle", Price = 99.99 },
                    new Product { Name = "Skateboard", Category = "Vehicle", Price = 24.99 },
                    new Product { Name = "Skirt", Category = "Clothing", Price = 17.5 }
                };

            // The lambda here uses a variable 'prod' which represents a product 
            // (although this may be named whatever you like)  
            //  The right hand side of the arrow is selecting Price as the thing we want to order by.

            // IEnumerable<Product> sortedProducts = myProducts.OrderByDescending(prod => prod.Price);//OrderByDescending fuction exsepta lambda
            
            // ViewBag.Products = sortedProducts; //for access

        //    IEnumerable<Product> sortedProducts = myProducts.OrderByDescending
        //    (prod => prod.Price).Where(prod=>prod.Name.StartsWith("S")).ToList(); //fillter
        //     ViewBag.Products = sortedProducts; //for access
           
        //    // just one item 
        //    Product justjeans = myProducts.FirstOrDefault(Prod=>Prod.Name == "Jeans");
        //     ViewBag.justjeans = justjeans;

         List<string> Food = new List<string>
            {
                "apple",
                "banana",
                "carrot",
                "fudge",
                "tomato"
            };

            List<string> Adjective = new List<string>
            {
            "tasty",
            "capital",
            "best",
            "typical",
            "flavorful",
            "toothsome",
            "fruity"
            };

            List<string> Alliterations = Food.Join(Adjective, foodItem => foodItem[0], adj => adj[0], (foodItem, adj) => {
                return adj + " " + foodItem;
            }).ToList();
            ViewBag.Allit = Alliterations;
           
            return View();

        }
       
    }
}


