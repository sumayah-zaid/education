using System;

namespace Demo.Models
{
    public class Product
    {
        public string Name {get;set;}
        public string Category {get;set;}
        public double Price {get;set;}
    }
}