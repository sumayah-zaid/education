﻿using System;
using System.Collections.Generic;

namespace MultiplicationTable
{
    class Program
    {
        static void Main(string[] args)
        {
        int [,] Multi = new int[10,10];
        
        for(int i = 1; i <= 10; i++)
            {
            for(int j = 1; j <= 10; j++)
            {
                Console.Write((i * j).ToString() + "\t");
            }
            Console.WriteLine();
            }
                    

        }
    }
}
