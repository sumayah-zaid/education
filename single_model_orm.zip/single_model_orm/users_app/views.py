from django.shortcuts import render, redirect
from .models import User
# show all of the data from a table
def index(request):
    context = {
    	"all_the_users": User.objects.all()
    }
    return render(request, "index.html", context)

def submit(request):
    print("Got Post Info....................")
    fname_from_add = request.POST['fname']
    lname_from_add = request.POST['lname']
    email_from_add = request.POST['email']
    age_from_add = request.POST['age']
    newly_created_user = User.objects.create(first_name=fname_from_add, 
    last_name=lname_from_add, email_address=email_from_add, 
    age=age_from_add)
    return redirect("/")