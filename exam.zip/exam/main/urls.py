from django.urls import path
from . import views

urlpatterns = [
    path("", views.root),
    path("register", views.register),
    path("login", views.login),
    path("dashboard", views.dashboard),
    path("logout", views.logout),
    path("new_trip", views.new_trip),
    path("create_trip", views.create_trip),
    path("delete/<int:id>", views.delete_trip),
    path("edit/<int:id>", views.edit_trip),
    path("update/<int:id>", views.update_trip),
    path("trips/<int:id>", views.trip_info),
    path("join/<int:id>", views.join_trip),
    path("cancel/<int:id>", views.cancel_trip),
]