﻿using System;

namespace Loop
{
    class Program
    {
        static void Main(string[] args)
        {
            // for (int i =1 ; i <256 ; i++){
            //     Console.WriteLine(i);
            // }

             for (int num =1 ; num <101 ; num++){
                 if ( num % 5 ==0 && num % 3 ==0 ){
                      Console.WriteLine("FizzBuzz");
                     
                 }
                 else if( num % 5 ==0){
                     Console.WriteLine("Buzz");
                 }
                  else if( num % 3 ==0){
                    Console.WriteLine("Fizz");
                 }
                
            }
            
        }
    }
}
